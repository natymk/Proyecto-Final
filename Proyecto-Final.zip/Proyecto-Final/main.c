#include <stdio.h>
#include <stdlib.h>
#include "sqlite3.h"
#include <string.h>

//Declaración de funciones
int ret= 0;
int print_record(void *, int, char **, char **);
int create_txt(void *, int, char **, char **);

//Función menú
int main()
{
    sqlite3 *db;
    char *err_msg = 0;
    int rc = sqlite3_open("clinica.db", &db); //Se crea el archivo .db


char *sql = "DROP TABLE IF EXISTS pacientes;"  // Elimine la tabla llamada pacientes si ya existe.

// Creando una nueva tabla llamada pacientes.

                "CREATE TABLE pacientes(NRC INT, ID INT,Nombre_del_paciente TEXT, Apellido_del_paciente TEXT, Edad INT, Fecha_de_nacimiento varchar, Nombre_y_apellido_del_doctor TEXT, Fecha_de_la_cita varchar, Diagnostico TEXT,Departamento TEXT, Tratamiento_medico_recomendado TEXT);"

// Insertar los valores en la tabla denominada pacientes.

                "INSERT INTO pacientes VALUES(1, '4 7531 9510', 'Lucia', 'Guardia Cerezo', '38', '16/09/1983', 'Alejandro Martí Giménez', '02/08/2021', 'Acné', 'Dermatología', 'Peróxido de benzoílo');"

                "INSERT INTO pacientes VALUES(2, '3 1582 9632', 'Víctor', 'García Montoya', '25', '25/06/1996', 'Francisco Palacios Ortega', '03/08/2021', 'Anemia', 'Hematología y Hemoterapia', 'Vitamina B12 o Acido fólico');"

                "INSERT INTO pacientes VALUES(3, '2 8932 2031', 'José Antonio', 'Pérez Gómez', '32', '20/08/1989', 'María Rosa Sánchez Navarro', '04/08/2021', 'Cistitis', 'Urología', 'Antibióticos');"

                "INSERT INTO pacientes VALUES(4, '1 5820 7913', 'Juan', 'Pérez Cayuela', '16', '12/05/2005', 'Manuel Samaniego Muñoz', '05/08/2021', 'Alergia', 'Alergología y Clínica Inmunología', 'Antihistamínicos');"

                "INSERT INTO pacientes VALUES(5, '1 9632 7412', 'Ana María', 'Velasco Sánchez', '52', '23/05/1969', 'Ana María García Arauz', '06/08/2021', 'Edema', 'Nefrología', 'Reposo en cama con elevación de extremidades');"

                "INSERT INTO pacientes VALUES(6, '5 8956 3215', 'Isabel', 'García Martínez', '29', '08/04/1992', 'Isabel Aguilar Sosa', '09/08/2021', 'Gripe', 'Medicina Interna', 'Se aconseja un reposo relativo y una buena hidratación');"

                "INSERT INTO pacientes VALUES(7, '6 8914 8523', 'Carlos', 'Rojas Rojas', '30', '17/10/1991', 'Carlos Duran Castillo', '10/08/2021', 'Hepatitis B', 'Hepatología', 'La hepatitis B crónica se trata con medicamentos antivirales, como interferón alfa, lamivudina, adefovir-dipivoxil, entecavir o combinaciones de los mismos');"

                "INSERT INTO pacientes VALUES(8, '1 1325 0265', 'Miguel', 'Calderón Suarez', '48', '10/02/1973', 'Miguel Salazar Mena', '11/08/2021', 'Insuficiencia cardiaca', 'Cardiología', 'En un primer momento se aplican medidas médico-farmacológicas');";


    if (rc != SQLITE_OK) { //Mensaje de error si no se puede abrir la base de datos
        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }
    rc = sqlite3_exec(db, sql, 0, 0, &err_msg);

    if (rc != SQLITE_OK ) {
        fprintf(stderr, "SQL error: %s\n", err_msg);
        sqlite3_free(err_msg);
        sqlite3_close(db);
        return 1;
    }


//menu----------
    int a;
	int opt;
	int opt2;
	char *k;
bis:
	do{
		//Inicialización opciones de menú
		opt=0;
		opt2=0;
		//Interfaz menú
		printf(" ______________________________________________________________________ \n");
		printf("|                                                                      |\n");
		printf("|------------------------   BASE DE DATOS   ---------------------------|\n");
		printf("|______________________________________________________________________|\n");
		printf("|                                                                      |\n");
		printf("| 1.                 Imprimir lista de pacientes                       |\n");
		printf("|_________________________________ ____________________________________|\n");
		printf("|                                 |                                    |\n");
		printf("| 2. Buscar paciente              | 3. Eliminar Paciente               |\n");
		printf("|_________________________________|____________________________________|\n");
		printf("|                                 |                                    |\n");
		printf("| 4. Exportar base datos en .txt  | 5. Salir                           |\n");
		printf("|_________________________________|____________________________________|\n");
		printf("Ingrese una opcion: ");
		scanf("%i", &opt);
			switch(opt){
				case 1:
					//IMPRIMIR LISTA DE PACIENTES
                printf("|Número de record clinico |          ID          |          Nombre       |      Apellidos        |         Edad        |     Fecha de nacimiento   | Doctor que lo/la atiende  | fecha de la cita      | Diagnostico      | Departamento      | Tratamiento     |\n");
                ret = sqlite3_exec(db, "select * from pacientes" , print_record, NULL, &err_msg);
                if(ret != SQLITE_OK){
                fprintf(stderr, "query SQL error: %s\n", err_msg);
                }
					break;

				case 2:
					//BUSCAR PACIENTE
                printf("Inserte Número de record clínico");
                scanf("%i", &a);
                sprintf(k, "SELECT * from pacientes where NRC=%i", a);
                ret = sqlite3_exec(db, k, print_record, NULL, &err_msg);
                if(ret != SQLITE_OK){
                fprintf(stderr, "query SQL error: %s\n", err_msg);
                }
					break;

				case 3:
                //ELIMINAR PACIENTE
                //Se le solicita al usuario el Nùmero de record clìnico del paciente que se desea eliminar de la base de datos
                printf("Inserte Número de record clínico");
                int b;
                scanf("%i", &b);
                sprintf(k, "DELETE from pacientes where NRC=%i", b); //Guarda el statement que se le quiere dar a la base de datos
                ret = sqlite3_exec(db, k, print_record, NULL, &err_msg); //Se ejecuta el statement
                if(ret != SQLITE_OK){
                fprintf(stderr, "query SQL error: %s\n", err_msg);
                }
					break;

				case 4:
				    //CREAR TXT de la tabla pacientes
                ret = sqlite3_exec(db, "select * from pacientes", create_txt, NULL, &err_msg); //Se selecciona la tabla de datos y se crea un archivo .txt mediante un
                                                                                                //callback a la funcion create_txt

                if(ret != SQLITE_OK){
                fprintf(stderr, "query SQL error: %s\n", err_msg);
                } else {
                printf("Creación de archivo .txt exitosa!");
                }
					break;

                case 5:
                break;

				default:
					printf("Opción inválida\n");
			}//END OF SWITCH
				if (opt!=5){
				printf("¿Desea hacer algo más?\n1.Volver al menú principal.\n2.Salir\n");
					scanf("%i",&opt2);
					if(opt2!=1){
						if(opt2!=2){
							printf("Opción inválida\n");
						}
						else{
							break;
						}
					}
				}else{break;}
			//END OF IF

	} while(opt!=5 && opt2!=2);//Mientras opt1 no sea 5 ni opt2 sea 2, seguirá entrando al menú
	//END OF DO WHILE
printf("Saliendo del programa (...)\n");


//-----------

    //Cierra base de datos
    sqlite3_close(db);

    return 0;
}//END OF MAIN


//Funcion imprimir lista en pantalla
int print_record(void *params, int n_column, char **column_value, char **column_name){
    int i;

    for(i=0; i<n_column;i++){ //Se imprimen todos los datos de cada paciente
       printf("\t%-20s|", column_value[i]);
    }
    printf("\n");
    return 0;
}


//Función crear .txt
int create_txt(void *params, int n_column, char **column_value, char **column_name)
{
    int i;
    int k = atoi(column_value[0]);


    if( k == 1 ){ //Se crea el archivo .txt
    FILE* fichero;
    fichero = fopen("DB.txt", "w");
    for(i=0; i<n_column;i++){ //Se imprimen los datos del primer paciente
       fprintf(fichero, "%s |", column_value[i]);
    }
    fprintf(fichero, "\n");

    fclose(fichero);
    }
    else{
    FILE* fichero;
    fichero = fopen("DB.txt", "a"); //Se abre el archivo .txt previamente creado y se agregan datos al final
    for(i=0; i<n_column;i++){
       fprintf(fichero, "%s |", column_value[i]);//Se agregan los demas datos de los demás pacientes
    }
    fprintf(fichero, "\n");
    fclose(fichero);
    }

    return 0;
}




